import Adminui from "./Components/Adminui";
import "./App.css";

const App = () => <Adminui />;

export default App;
